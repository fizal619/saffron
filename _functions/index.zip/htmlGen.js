module.exports = (event) => {
  const {
    customer,
    email,
    date = "",
    phone = "",
    bag = {},
    body = "",
    address = "",
    type
  } = JSON.parse(event.body);

  if (type === "CONTACT") {
    return `
    <!DOCTYPE html>
    <html>
      <style>
        font-family: sans-serif;
        margin: 25px 50px;
      </style>
      <head></head>
      <h1>${type}</h1>
      <h4>${customer} (${email}) said:</h4>
      <p>${body}</p>
      <br>
      <p>This messages was sent from a unmonitored mailbox. Please do not reply to it. Contact supriya@saffroncateringgy.com with any concerns</p>
    </html>
  `;
  }

  if (type === "ORDER") {
    const items = Object.values(bag);
    let runningTotal = 0;
    return `
      <!DOCTYPE html>
      <html>
        <style>
          font-family: sans-serif;
          margin: 25px 50px;
        </style>
        <head></head>
        <h1>${type}</h1>
        <h4>${customer} (${email}, ${phone})</h4>
        <p>${address}</p>
        ${items.reduce((p,c) => {
          return p + `
            <p><b>${c.qty}</b> x ${c.name} ${c.option}<p>
            <p>Special instructions: ${c.instructions || "none"}</p>
            <p><b>${runningTotal = c.qty * c.price || c.qty * c.price}</b></p>
            <br/>
          `
        }, "")}
        <br>
        <p>Total: ${runningTotal}</p>
        <p>Pickup/Delivery Date: ${date}</p>
        <br>
        <p>A representative will call you soon to confirm your order.</p>
        <br/>
        <p>This messages was sent from a unmonitored mailbox.</p>
        <p>Please do not reply to it. Contact supriya@saffroncateringgy.com with any concerns</p>
      </html>
    `;
  }


}